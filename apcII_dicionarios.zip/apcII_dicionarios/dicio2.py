
#Criando um dicionario
amigos = {
    "Joao": 25,
    "Ana": 30,
    "Carlos": 28
}

#definindo posições 
for nome, idade in amigos.items():
    print(f"{nome} tem {idade} anos.")

#input para verificar se nome esta no dicionario
nome_amigo = input("Digite um nome: ")
if nome_amigo in amigos:
    print(f"{nome_amigo} está na lista de amigos.")
else:
    print(f"{nome_amigo} não está na lista de amigos")

#conta quantidade de amigos na lista
quant_amigos = len(amigos)
print(f"Existem {quant_amigos} amigos na lista")