#exrcicio de elaborar uma classe Pessoa que tenha o metodo construtor nome e sobrenome
#metodos dormir
class Pessoa:
    def __init__(self, nome, sobrenome):
        self.nome = nome
        self.sobrenome = sobrenome
    
    def dormir(self):
        print(f"{self.nome} {self.sobrenome} está dormindo")

pessoa1 = Pessoa("Carlos", "Santana")
pessoa1.dormir()

