estoque = {
    "camisetas": 50,
    "shorts": 75,
    "tênis": 25,
    "bonés": 23,
    "meias": 50

}

produto = input("Insira o produto desejado: ")
if produto in estoque:
    print(f"{produto} está no estque com {estoque[produto]} unidades disponíveis")
else:
    print(f"{produto} não está disponivel no estoque")