#objetivo, tentar criar uma ficha de cadastro com POO

class Cliente:
    def __init__(self, ID, nome, email, telefone):
        self.ID = ID
        self.nome = nome
        self.email = email
        self.telefone = telefone

        Cliente.total_clientes += 1
    
