traducao = {
    "hello": "hola",
    "goodbye": "adiós",
    "thank you": "gracias"
}

traducao["hello"] = "Olá"
traducao["goodbye"] = "Adeus"
traducao["thank you"] = "Obrigado"
print("Dicionario atualizado:", traducao)
print("Dicionario atualizado:", traducao)
print("Dicionario atualizado:", traducao)


palavra_ingles = input("digite uma palavra em inglês: ")
if palavra_ingles in traducao:
    print(f"A tradução de {palavra_ingles} é {traducao[palavra_ingles]}.")
else:
    print("Essa palavra não está no dicionario de tradução")

