dicionario1 = {"a":1, "b":2}
dicionario2 = {"c":3, "d":4}

dicio_mesclado = {**dicionario1, **dicionario2}

print("Dicionário mesclado: ", dicio_mesclado)