#LINK EXERCICIOS SOBRE DICIONÁRIOS
#https://acadianschool.com.br/dominando-dicionarios-em-python-15-exercicios-para-aperfeicoar-suas-habilidades-de-programacao/

#criando dicionario
funcionario = {
    "nome": "Carlos Augusto",
    "matricula": 471684816,
    "cargo": "Facilities",
}


#manipulando dados do dicionário
nome_funcionario = funcionario["nome"]
matricula_funcionario = funcionario["matricula"]
cargo_funcionario = funcionario["cargo"]

#exibindo no console
print("Nome:", nome_funcionario)
print("Matricula:", matricula_funcionario)
print("Cargo:", cargo_funcionario)

#atualizando valores

#nome do dicionario[campo que quero alterar] = "Alterar"
#print(dicionario)
funcionario["cargo"] = "Assistente Administrativo"
print("Dicionario atualizado:", funcionario)

#adicionando novos campos ao dicionario
funcionario["email"] = "carlos.augusto@email.com"
funcionario["ramal"] = 4525
print("Dicionario atualizado:", funcionario)

#criando if para deletar campo
if "ramal" in funcionario:
    del funcionario["ramal"]
print("Dicionario atualizado:", funcionario)