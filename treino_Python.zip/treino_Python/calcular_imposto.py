
def calculo(valor):
    if valor <1000:
        imposto = valor*0.1
    elif valor <2000:
        imposto = valor * 0.13
    else:
        imposto = valor*0.2
    return imposto

# preco = int(input("insira o valor do produto: "))

# imposto_produto = calculo(preco)

# print(f'O imposto embutido é: {imposto_produto}')


produto1 = int(input("Insira o valor do produto: "))
produto2 = int(input("Insira o valor do segundo produto: "))

imposto_produto1 = calculo(produto1)
imposto_produto2 = calculo(produto2)

print(f"O imposto do primeiro produto é {imposto_produto1}")
print(f"O imposto do segundo produto é: {imposto_produto2}")
